Scripted replacement for Ahk2Exe
================================

Installation
------------

Just copy everything to your AutoHotkey\Compiler folder (make sure to backup the existing Ahk2Exe.exe!)
The source code to the compiler can be found at https://github.com/HotKeyIt/Ahk2Exe.

TODO
----

Handle FileInstall on same-line If* commands.
